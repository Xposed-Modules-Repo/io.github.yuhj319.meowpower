// ============================================================================
//  TextPatch —— 定点替换插件（只改 #112，其它文本一律不动）
//
//  目标项：#112 = 电池健康度百分比
//          页面   com.miui.powercenter.nightcharge.ChargerProtectActivity
//          原文   "100%"
//          资源   com.miui.securitycenter:string/percent_formatted_text
//          （数据来自 TextIndexer 日志 text_index_0921_233909.txt 第 112 行）
//
//  原理：Hook TextView.setText，识别出 #112 那一项，把它的显示内容换成 NEW_TEXT_112；
//        其它任何文本都原样放行，不做编号、不做修改。
// ============================================================================

import android.app.Activity
import android.content.ContextWrapper

// ============================================================================
// ★★★★★★★★★★  唯一需要配置的地方（直接改这里）  ★★★★★★★★★★
// ============================================================================

// #112 要显示成什么？想写什么就写什么：
//     "88%"          -> 显示 88%
//     "健康度 88%"    -> 带文字的
//     "优秀"          -> 纯文本
//     ""             -> 清空（不显示）
NEW_TEXT_112 = "88%"

// --- #112 的识别参数（一般不用动）---
TARGET_INDEX  = 112                        // #112 的编号
TARGET_TEXT   = "100%"                     // #112 的原文
BIND_ACTIVITY = "ChargerProtectActivity"   // 限定页面（"" = 不限定）
BIND_RES      = "percent_formatted_text"   // 资源名校验（"" = 不校验）

// --- 三种识别方式，任一命中即替换（想只按编号就把后两个设为 false）---
USE_INDEX_MATCH = true     // ① 按编号 112 匹配（编号 112 已锚定到上面的 TARGET_TEXT，不会漂移）
USE_RES_MATCH   = true     // ② 按资源名匹配（电池健康度变成 99% 之类时也不会漏）
USE_TEXT_MATCH  = false    // ③ 按原文精确匹配 "100%"

// ============================================================================
// 以下为插件逻辑，不需要修改
// ============================================================================

INHOOK   = new java.lang.ThreadLocal()   // 防重入
PENDING  = new java.lang.ThreadLocal()   // setText(int resid) 传下来的资源 id
VALUE2RES= new java.util.HashMap()       // 字符串值 -> 资源名
HIT      = new int[1]                    // 替换次数
OTHERCNT = new int[1]                    // 其它文本的内部计数（仅日志用，不显示）
LASTACT  = new String[1]

OTHERCNT[0] = TARGET_INDEX
LASTACT[0] = "?"

clsOf(name) { return Class.forName(name, false, hostLoader) }

resNameOf(id) {
    try { return hostContext.getResources().getResourceName(id) } catch (Throwable t) { return "" }
}

// 当前文本所属 Activity（取不到时返回 "?"，此时不做页面过滤，避免漏替换）
activityOf(ctx) {
    c = ctx
    i = 0
    while (c != null && i < 20) {
        if (c instanceof Activity) { return c.getClass().getName() }
        if (c instanceof ContextWrapper) { c = ((ContextWrapper) c).getBaseContext() } else { c = null }
        i = i + 1
    }
    if (LASTACT[0] != null) { return LASTACT[0] }
    return "?"
}

// 页面校验（"?" = 取不到页面信息 → 放行，保证有效）
actOk(act) {
    if (BIND_ACTIVITY == null || BIND_ACTIVITY.length() == 0) { return true }
    if (act == null || act.length() == 0 || "?".equals(act)) { return true }
    return act.indexOf(BIND_ACTIVITY) >= 0
}

// 资源名校验（只有能取到资源名并且明显不匹配时才否决，避免误杀）
resOk(rn) {
    if (BIND_RES == null || BIND_RES.length() == 0) { return true }
    if (rn == null || rn.length() == 0) { return true }
    return rn.indexOf(BIND_RES) >= 0
}

// 内部编号：TARGET_TEXT 固定锚定为 TARGET_INDEX(#112)，其它文本顺延（只用于识别，永不显示）
indexOfText(txt) {
    if (TARGET_TEXT != null && TARGET_TEXT.length() > 0 && txt.equals(TARGET_TEXT)) { return TARGET_INDEX }
    OTHERCNT[0] = OTHERCNT[0] + 1
    return OTHERCNT[0]
}

setArgSafe(param, val) {
    try {
        INHOOK.set(Boolean.TRUE)
        param.setArg(0, val)
    } catch (Throwable t) {
        log("[TextPatch] setArg fail: " + t)
    } finally { INHOOK.remove() }
}

// ---------------------------- 核心逻辑 ----------------------------
applyOne(param) {
    a0 = param.args[0]
    if (a0 == null) { return }
    if (a0 instanceof Integer) { PENDING.set(a0); return }     // setText(int resid)
    if (!(a0 instanceof CharSequence)) { return }
    if (INHOOK.get() != null) { return }

    txt = a0.toString()
    if (txt == null || txt.length() == 0) { PENDING.remove(); return }

    tv  = param.thisObject
    cls = "?"
    act = "?"
    if (tv != null) {
        cls = tv.getClass().getName()
        act = activityOf(tv.getContext())
    }
    if (cls.indexOf("EditText") >= 0) { PENDING.remove(); return }

    // 资源名：优先用 setText(int resid) 带下来的 id，其次用 getString/getText 记录过的值
    rid = PENDING.get()
    PENDING.remove()
    rn = ""
    if (rid != null) { rn = resNameOf(rid) }
    if (rn.length() == 0) {
        v0 = VALUE2RES.get(txt)
        if (v0 != null) { rn = v0 }
    }

    idx = indexOfText(txt)

    matched = false
    if (USE_INDEX_MATCH && idx == TARGET_INDEX && actOk(act)) { matched = true }
    if (!matched && USE_RES_MATCH && resOk(rn) && actOk(act) && rn.length() > 0 && BIND_RES.length() > 0) { matched = true }
    if (!matched && USE_TEXT_MATCH && TARGET_TEXT.length() > 0 && txt.equals(TARGET_TEXT) && actOk(act)) { matched = true }

    if (!matched) { return }                                   // ← 其它文本一律不动

    if (!NEW_TEXT_112.equals(txt)) {
        HIT[0] = HIT[0] + 1
        log("[TextPatch] 命中 #" + idx + " [" + rn + "] " + cls + " @ " + act + " : " + txt + "  ==>  " + NEW_TEXT_112)
        setArgSafe(param, NEW_TEXT_112)
    }
}

capRes(param) {
    a0 = param.args[0]
    r  = param.result
    if (a0 == null || r == null) { return }
    if (!(a0 instanceof Integer)) { return }
    if (!(r instanceof CharSequence)) { return }
    try { VALUE2RES.put(r.toString(), resNameOf(a0)) } catch (Throwable t) { }
}

// ---------------------------- 安装 Hook ----------------------------
try {
    resCls = clsOf("android.content.res.Resources")
    hookAllMethodsAfter(resCls, "getText", p -> { try { capRes(p) } catch (Throwable t) { } })
} catch (Throwable t) { }
try {
    resCls2 = clsOf("android.content.res.Resources")
    hookAllMethodsAfter(resCls2, "getString", p -> { try { capRes(p) } catch (Throwable t) { } })
} catch (Throwable t) { }

try {
    tvCls = clsOf("android.widget.TextView")
    hookAllMethodsBefore(tvCls, "setText", p -> {
        try { applyOne(p) } catch (Throwable t) { log("[TextPatch] err: " + t) }
    })
    log("[TextPatch] hook TextView.setText : OK")
} catch (Throwable t) {
    log("[TextPatch] hook TextView.setText fail: " + t)
}

try {
    cpCls = clsOf("com.miui.powercenter.nightcharge.ChargerProtectActivity")
    hookAllMethodsAfter(cpCls, "onCreate", p -> { LASTACT[0] = "com.miui.powercenter.nightcharge.ChargerProtectActivity" })
} catch (Throwable t) { }

// ---------------------------- 启动信息 ----------------------------
log("[TextPatch] READY  #" + TARGET_INDEX + " (" + TARGET_TEXT + ")  ==>  " + NEW_TEXT_112)
log("[TextPatch] 页面=" + BIND_ACTIVITY + "  资源=" + BIND_RES + "  匹配方式: index=" + USE_INDEX_MATCH + " res=" + USE_RES_MATCH + " text=" + USE_TEXT_MATCH)
try { toast("#112 -> " + NEW_TEXT_112) } catch (Throwable t) { }
